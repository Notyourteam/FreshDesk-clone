import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { LoginService } from 'src/app/services/loginService/login.service';
import { UserService } from 'src/app/services/userService/user-service.service';
import { TicketPost } from 'src/app/Utilities/Tickets/TicketPost';
import { User } from 'src/app/Utilities/Users/User'
@Component({
  selector: 'app-ticket-detail',
  templateUrl: './ticket-detail.component.html',
  styleUrls: ['./ticket-detail.component.css']
})
export class TicketDetailComponent implements OnInit {
  date = new Date()
  form!: FormGroup;
  isEdit: boolean = false;
  isUpdate: boolean = false;
  priorities = ['low','medium','high','very high'];
  status = ['open','inprogress','closed','overdue','resolved'];
  types = ['Question','Incident','Problem','Feature Request','Refund'];
  allusers: User[]=[]
  private formSubmitAttempt!: boolean;
  currentUser:User | undefined;
  Ticket = new TicketPost();
  temp: any = []
  constructor(
    private router: Router,
    private fb: FormBuilder,
    private UserService: LoginService,
    private TicketService:UserService,
    private activatedRoute: ActivatedRoute,
  ) {    if (this.router.getCurrentNavigation() != null) {
    const state = this.router.getCurrentNavigation()?.extras.state;
    if(state==undefined||state==null)
    {
      this.router.navigate(['']);
    }
    this.temp = state;
    this.Ticket = this.temp.sub;
    this.isEdit = this.temp.isEdit;
    console.log(this.Ticket.id)
  }}


  ngOnInit(): void {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser') || '[]')
    this.UserService.getAllUser().subscribe((res: any) => {
      this.allusers = res.filter((e: { emailId: string | undefined; })=>e.emailId!=this.currentUser?.emailId);
    });
    if(!this.currentUser?.emailId)
    {
      this.router.navigate(['login'])
    }
    if(this.isDue()<0)
    {
      this.Ticket.status='overdue';
    }
    this.form = this.fb.group({
      subject: [this.Ticket.subject, Validators.required],
      type: [this.Ticket.type, Validators.required],
      priority: [this.Ticket.priority, Validators.required],
      description: [this.Ticket.description, Validators.required],
      agentname: [this.Ticket.agentName, Validators.required],
      dueBy: [this.Ticket.dueBy, Validators.required],
      status: [this.Ticket.status, Validators.required],
    });
  }
  isFieldInvalid(field: string) {
    return (
      (!this.form.get(field)?.valid && this.form.get(field)?.touched) ||
      (this.form.get(field)?.untouched && this.formSubmitAttempt)
    );
  }
  onSubmit() {
    if (this.form.valid) {
    }
    this.formSubmitAttempt = true;
    console.log(this.form.value)
    this.assignTicket()
  }
  assignTicket()
  {
    this.Ticket.authorEmail = this.currentUser?.emailId!;
    this.Ticket.agentName = this.form.value.agentname;
    this.Ticket.agentEmail = this.allusers.find((e: { name: string | undefined; })=>e.name==this.form.value.agentname)?.emailId!;
    this.Ticket.subject = this.form.value.subject;
    this.Ticket.type = this.form.value.type;
    this.Ticket.priority = this.form.value.priority;
    this.Ticket.description = this.form.value.description;
    this.Ticket.dueBy = this.form.value.dueBy;
    this.Ticket.status = this.form.value.status;
    this.Ticket.name = this.currentUser?.name!;
    console.log(this.Ticket)
    this.TicketService.updateTicket(this.Ticket).subscribe((data: any) => {
      console.log(data);
      this.cancel();
    });
  }
  updateTicket(status:string)
  {
    this.Ticket.status = status;
    this.TicketService.updateTicket(this.Ticket).subscribe((data: any) => {
      console.log(data);
      this.cancelUpdate();
    });
  }
  cancelUpdate()
  {
    this.isUpdate= false;
  }
  cancel()
  {
    this.isEdit=false;
  }
  RemainingTime(datestring: string)
  {
    var time = new Date().getTime() - new Date(datestring).getTime();
    return time
  }
  inBetween(datestring: string) {
    var one_day=1000*60*60*24;
    var date1_ms = new Date().getTime()
    var date2_ms = new Date(datestring).getTime();
    var difference_ms =  date1_ms-date2_ms;
    return Math.round(difference_ms/one_day);
  }
  isDue(){
    let date1 = new Date().getTime()
    let date2 = new Date(this.Ticket.dueBy).getTime();
    var diff = Math.abs(date1 - date2);
    var diffDays = Math.ceil(diff / (1000 * 3600 * 24));
    return diffDays;
  }
  userAccess()
  {
    if(this.Ticket.authorEmail == this.currentUser?.emailId)
      return true;
    else if(this.currentUser?.admin==1)
      return true;
    else return false;
  }
  userAccessAgent()
  {
    if(this.Ticket.agentEmail == this.currentUser?.emailId)
      return true;
    else if(this.currentUser?.admin==1)
      return true;
    else return false;
  }
  isUpdated()
  {
    this.isUpdate = true;
  }
}
