import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/loginService/login.service';
import { UserService } from 'src/app/services/userService/user-service.service';
import { TicketPost } from 'src/app/Utilities/Tickets/TicketPost';
import { User } from 'src/app/Utilities/Users/User';
@Component({
  selector: 'app-create-task',
  templateUrl: './create-task.component.html',
  styleUrls: ['./create-task.component.css']
})
export class CreateTaskComponent implements OnInit {
  date = new Date()
  form!: FormGroup;
  priorities = ['low','medium','high','very high'];
  types = ['Question','Incident','Problem','Feature Request','Refund']
  allusers: User[]=[]
  private formSubmitAttempt!: boolean;
  currentUser:User | undefined;
  Ticket = new TicketPost();
  constructor(
    private router: Router,
    private fb: FormBuilder,
    private UserService: LoginService,
    private TicketService:UserService,
  ) {}

  ngOnInit() {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser') || '[]')
    this.UserService.getAllUser().subscribe((res: any) => {
      this.allusers = res.filter((e: { emailId: string | undefined; })=>e.emailId!=this.currentUser?.emailId);
    });
    if(!this.currentUser?.emailId)
    {
      this.router.navigate(['login'])
    }
    this.form = this.fb.group({
      subject: ['', Validators.required],
      type: ['', Validators.required],
      priority: ['', Validators.required],
      description: [''],
      agentname: ['', Validators.required],
      dueBy: ['', Validators.required],
    });
  }

  isFieldInvalid(field: string) {
    return (
      (!this.form.get(field)?.valid && this.form.get(field)?.touched) ||
      (this.form.get(field)?.untouched && this.formSubmitAttempt)
    );
  }

  onSubmit() {
    if (this.form.valid) {
    }
    this.formSubmitAttempt = true;
    console.log(this.form.value)
    this.assignTicket()
  }
  assignTicket()
  {
    this.Ticket.authorEmail = this.currentUser?.emailId!;
    this.Ticket.agentName = this.form.value.agentname;
    this.Ticket.agentEmail = this.allusers.find((e: { name: string | undefined; })=>e.name==this.form.value.agentname)?.emailId!;
    this.Ticket.subject = this.form.value.subject;
    this.Ticket.type = this.form.value.type;
    this.Ticket.priority = this.form.value.priority;
    this.Ticket.description = this.form.value.description;
    this.Ticket.dueBy = this.form.value.dueBy;
    this.Ticket.createdAt = this.date.toISOString().slice(0, -5);
    this.Ticket.status = 'open';
    this.Ticket.name = this.currentUser?.name!;
    console.log(this.Ticket)
    this.TicketService.addTicket(this.Ticket).subscribe((data: any) => {
      console.log(data);
      this.cancel();
    });
  }
  cancel()
  {
    this.router.navigate(['']);
  }

}
