import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginService } from 'src/app/services/loginService/login.service';
import { TicketData } from 'src/app/Utilities/Tickets/TicketData';
import { User } from 'src/app/Utilities/Users/User';

@Component({
  selector: 'app-user-detail',
  templateUrl: './user-detail.component.html',
  styleUrls: ['./user-detail.component.css']
})
export class UserDetailComponent implements OnInit {
  UserEmail!: string;
  User: User | undefined;
  temp: any = []
  Tickets:TicketData[]=[];
  constructor(private router: Router,
    private fb: FormBuilder,
    private UserService: LoginService,
    private activatedRoute: ActivatedRoute,)  {    if (this.router.getCurrentNavigation() != null) {
      const state = this.router.getCurrentNavigation()?.extras.state;
      if(state==undefined||state==null)
      {
        this.router.navigate(['']);
      }
      this.temp = state;
      this.UserEmail = this.temp.navEmail;
      this.UserService.getUser(this.UserEmail).subscribe((res: any) => {
        this.User=res;
        this.Tickets = res.tickets;
        console.log(this.Tickets,res)
      });
    }}

  ngOnInit(): void {
  }

}
