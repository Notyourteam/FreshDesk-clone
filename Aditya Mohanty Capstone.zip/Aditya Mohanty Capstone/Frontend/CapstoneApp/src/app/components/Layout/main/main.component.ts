import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/app/Utilities/Users/User';
import { ActivatedRoute } from '@angular/router'

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {
  currentUser: User|undefined;
  constructor(private router: Router, private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser') || '[]')
    console.log(this.currentUser)
    if(!this.currentUser?.emailId)
    {
      this.router.navigate(['login'])
    }
  }
  userLogout()
  {
    localStorage.clear();
    this.router.navigate(['login']);
  }
  addTask()
  {
    console.log(this.activatedRoute)
    this.router.navigate(['create'], {relativeTo: this.activatedRoute});
  }
  goToTable(event:Event)
  {
    event.preventDefault();
    this.router.navigate(['']);
  }
}
