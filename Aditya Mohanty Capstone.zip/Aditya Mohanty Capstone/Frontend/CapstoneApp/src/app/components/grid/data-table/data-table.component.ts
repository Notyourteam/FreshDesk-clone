import { Component, OnInit ,ViewChild,AfterViewInit,OnChanges, SimpleChanges} from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { TicketData } from 'src/app/Utilities/Tickets/TicketData';
import { Ticket, TicketColumns } from 'src/app/Utilities/Tickets/Ticket';
import { DeleteDialogComponent } from '../delete-dialog/delete-dialog.component';
import { UserService } from 'src/app/services/userService/user-service.service';
import { User } from 'src/app/Utilities/Users/User';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-data-table',
  templateUrl: './data-table.component.html',
  styleUrls: ['./data-table.component.css']
})
export class DataTableComponent implements OnInit,AfterViewInit,OnChanges{

  displayedColumns: string[] = TicketColumns.map((col) => col.key);
  columnsSchema: any = TicketColumns;
  dataSource = new MatTableDataSource<Ticket>();
  valid: any = {};
  delete: boolean = false;
  edit: boolean = false;
  add: boolean = false;
  mulDel: boolean = false;
  idNew: number = 0;
  currentUser:User | undefined;
  Selected:TicketData[]=[];
  allSelected: boolean = false;
  indeterminate: boolean = false;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  constructor(public dialog: MatDialog, private userService: UserService,private router: Router,private activatedRoute:ActivatedRoute) { }

  ngOnInit() {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser') || '[]')
    this.userService.getTickets().subscribe((res: any) => {
      this.dataSource.data = res;
      console.log(res)
    });
  }
  ngAfterViewInit(){
    this.dataSource.paginator=this.paginator;
    this.dataSource.sort=this.sort;
  }
  ngOnChanges(changes: SimpleChanges): void {
      console.log(changes);
  }

  editRow(element: any) {
    console.log(element)
    this.router.navigate(['TicketDetails'], {
      relativeTo: this.activatedRoute,
      state: {element},
    });
  }



  removeRow(element: any) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    let dialogRef = this.dialog.open(DeleteDialogComponent, dialogConfig);
    this.edit = true;
    this.delete = true;
    this.add = true;
    this.mulDel = true;
    dialogRef.afterClosed().subscribe(
      data => {
        console.log(data);
        this.edit = false;
        this.delete = false;
        this.add = false;
        this.mulDel = false;
        if (data === true) {
          console.log(this.dataSource.data);
          this.dataSource.data = this.dataSource.data.filter(function (item) {
            return item.id !== element.id;
          });
          console.log(this.dataSource.data);
          this.userService.deleteTicket(element.id).subscribe((data: any) => {
            console.log(data);
          });
        }
      });

  }

  removeSelectedRows() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    let dialogRef = this.dialog.open(DeleteDialogComponent, dialogConfig);
    this.edit = true;
    this.delete = true;
    this.add = true;
    this.mulDel = true;
    dialogRef.afterClosed().subscribe(
      data => {
        console.log(data);
        this.edit = false;
        this.delete = false;
        this.add = false;
        this.mulDel = false;
        if (data === true) {
          console.log(this.dataSource.data);
          this.Selected=this.dataSource.data.filter(function (item) {
            return item.isSelected;
          });
          this.dataSource.data = this.dataSource.data.filter(function (item) {
            return !item.isSelected;
          });
          this.userService.deleteTickets(this.Selected).subscribe((data: any)=>{
             console.log(data);
          });
        }
      });
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

  }
  gotoDtail(event:Event,sub:TicketData,isEdit:boolean)
  {
    event.preventDefault();
    console.log(sub)
    this.router.navigate(['TicketDetails'], {
      relativeTo: this.activatedRoute,
      state: {sub,isEdit},
    });
  }
  selectionChanged(item: { isSelected: any; }, event: { checked: any; }) {
    item.isSelected = event.checked;

    let totalSelected = this.dataSource.data.filter(i => i.isSelected).length;
    if(totalSelected === 0) {
      this.allSelected = false;
      this.indeterminate = false;
    } else if(totalSelected > 0 && totalSelected < this.dataSource.data.length) {
      this.allSelected = false;
      this.indeterminate = true;
    } else if(totalSelected === this.dataSource.data.length) {
      this.allSelected = true;
      this.indeterminate = false;
    }
  }
  toggleSelectAll(event:boolean) {
    this.allSelected = event;
    this.dataSource.data.forEach(item => {
      item.isSelected = event;
    });
  }
  gotoProfile(event:Event,sub:TicketData)
  {
    let navEmail = sub.authorEmail;
    event.preventDefault();
    console.log(sub.authorEmail)
    this.router.navigate(['UserDetails'], {
      relativeTo: this.activatedRoute,
      state: {navEmail},
    });
  }

}
