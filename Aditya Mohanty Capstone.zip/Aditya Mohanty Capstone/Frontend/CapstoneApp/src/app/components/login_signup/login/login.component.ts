import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/loginService/login.service';
import { User } from 'src/app/Utilities/Users/User';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  form!: FormGroup;
  private formSubmitAttempt!: boolean;
  currentUser:User | undefined;
  constructor(
    private router: Router,
    private fb: FormBuilder,
    private LoginUser: LoginService
  ) {}

  ngOnInit() {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser') || '[]')
    console.log(this.currentUser)
    if(this.currentUser?.emailId)
    {
      this.router.navigate(['table'])
    }
    this.form = this.fb.group({
      email_id: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  isFieldInvalid(field: string) {
    return (
      (!this.form.get(field)?.valid && this.form.get(field)?.touched) ||
      (this.form.get(field)?.untouched && this.formSubmitAttempt)
    );
  }

  onSubmit() {
    if (this.form.valid) {
    }
    this.formSubmitAttempt = true;
    console.log(this.form.value)
    this.LoginUser.getUser(this.form.value.email_id).subscribe((res: any) => {
      console.log(res)
      this.verifyUser(res)
    });
  }
  verifyUser(res:any)
  {
    if(this.form.value.email_id==res.emailId && this.form.value.password==res.password)
    {
      this.router.navigate([''])
      this.currentUser = res;
      localStorage.setItem('currentUser',JSON.stringify(this.currentUser))
    }
    else
    alert("incorrent username or password")
  }
  signUp(event:Event)
  {
    event.preventDefault();
    this.router.navigate(['signup'])
  }
}
