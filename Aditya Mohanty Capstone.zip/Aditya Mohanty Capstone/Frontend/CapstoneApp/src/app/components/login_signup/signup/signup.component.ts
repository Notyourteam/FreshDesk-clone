import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/loginService/login.service';
import { MyErrorStateMatcher } from 'src/app/Utilities/ErrorStateMatcer/MyErrorStateMatcher';
import { User } from 'src/app/Utilities/Users/User';
import { UserPost } from 'src/app/Utilities/Users/UserPost';
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  matcher = new MyErrorStateMatcher();
  form!: FormGroup;
  private formSubmitAttempt!: boolean;
  currentUser:User | undefined;
  userPost = new UserPost();
  checkPasswords: ValidatorFn = (group: AbstractControl):  ValidationErrors | null => {
    let pass = group.get('password')?.value;
    let confirmPass = group.get('confirmPassword')?.value
    return pass === confirmPass ? null : { notSame: true }
  }
  constructor(
    private router: Router,
    private fb: FormBuilder,
    private LoginUser: LoginService
  ) {}

  ngOnInit() {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser') || '[]')
    console.log(this.currentUser)
    if(this.currentUser?.emailId)
    {
      this.router.navigate(['table'])
    }
    this.form = this.fb.group({
      email_id: ['', Validators.required],
      password: ['', Validators.required],
      name: ['', Validators.required],
      confirmPassword: ['']
    }, { validators: this.checkPasswords });
  }

  isFieldInvalid(field: string) {
    return (
      (!this.form.get(field)?.valid && this.form.get(field)?.touched) ||
      (this.form.get(field)?.untouched && this.formSubmitAttempt)
    );
  }

  onSubmit() {
    if (this.form.valid) {
    }
    this.formSubmitAttempt = true;
    this.userPost.emailId = this.form.value.email_id;
    this.userPost.password = this.form.value.password;
    this.userPost.name = this.form.value.name;
    console.log(this.form.value)
    this.LoginUser.addUser(this.userPost).subscribe((data: any) => {
      console.log(data);
      this.router.navigate(['login'])
    });
  }
  navlogin(event :Event)
  {
    event.preventDefault();
    this.router.navigate(['login'])
  }
}
