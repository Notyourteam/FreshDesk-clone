import { Ticket } from "../Tickets/Ticket";

export interface User {
  emailId: string,
  password: string,
  name: string,
  admin: number,
  Ticket: Ticket[]
  }
