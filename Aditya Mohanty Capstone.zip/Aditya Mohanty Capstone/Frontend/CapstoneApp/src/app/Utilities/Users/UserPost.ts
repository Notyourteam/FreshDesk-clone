export class UserPost {
  emailId: string='';
  password: string='';
  name: string='';
  admin: number=0;
  }
