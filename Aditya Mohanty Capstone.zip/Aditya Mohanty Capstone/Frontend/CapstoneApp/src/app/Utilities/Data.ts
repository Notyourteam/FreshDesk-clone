/* export interface Data {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
    birthDate: string;
  } */
export interface Data {
  id: number;
  name:string;
  phone:string;
  email:string;
  subject:string;
  type:string;
  status:string;
  priority:string;
  description:string;
  responder_id:number;
  due_by:Date;
  CreatedAt:Date;
  fr_due_by:Date;
  reply_emails: Array<string>;
  reply_txt:Array<string>;
}
