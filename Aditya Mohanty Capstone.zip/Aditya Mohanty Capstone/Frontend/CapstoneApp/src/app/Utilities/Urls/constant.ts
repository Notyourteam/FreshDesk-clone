import { environment } from 'src/environments/environment';

export module Constant {
  const baseUrl: String = environment.baseURL;
  export const getEndpoint: String = `${baseUrl}/api/Tickets`;
  export const deleteEndPoint: string = `${baseUrl}/api/Tickets/`;
  export const loginEndPoint: string = `${baseUrl}/api/UserLogins/`
}
