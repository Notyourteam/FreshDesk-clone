export class TicketPost{
  name: string='';
  authorEmail: string='';
  subject: string='';
  type: string='';
  status: string='';
  priority: string='';
  description: string='';
  agentName: string='';
  agentEmail: string='';
  dueBy: string='';
  createdAt: string='';
  id: any;
}
