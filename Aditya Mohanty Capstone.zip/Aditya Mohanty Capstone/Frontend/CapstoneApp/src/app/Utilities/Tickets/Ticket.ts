export interface Ticket{
  isSelected: boolean;
  id: number
  name: string,
  authorEmail: string,
  subject: string,
  type: string,
  status: string,
  priority: string,
  description: string,
  agentName: string,
  agentEmail: string,
  dueBy: string,
  createdAt: string,
  isEdit: boolean;
}

export const TicketColumns = [
  {
    key: 'isSelected',
    type: 'isSelected',
    label: '',
  },
  {
    key: 'subject',
    type: 'link',
    label: 'Subject',
  },
  {
    key: 'priority',
    type: 'text',
    label: 'Priority',
    required: true
  },
  {
    key: 'name',
    type: 'profilelink',
    label: 'Contact',
    required: true,
  },
  {
    key: 'type',
    type: 'text',
    label: 'Type',
    required: true,
  },
  {
    key:'status',
    type:'number',
    label:'Status',
    required: true,
  },
  {
    key: 'isEdit',
    type: 'isEdit',
    label: 'Edit',
  },
];
