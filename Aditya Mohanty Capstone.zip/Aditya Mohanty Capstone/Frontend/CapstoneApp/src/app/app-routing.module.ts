import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateTaskComponent } from './components/children/create-task/create-task.component';
import { DataTableComponent } from './components/grid/data-table/data-table.component';
import { LoginComponent } from './components/login_signup/login/login.component';
import { MainComponent } from './components/Layout/main/main.component';
import { SignupComponent } from './components/login_signup/signup/signup.component';
import { TicketDetailComponent } from './components/children/ticket-detail/ticket-detail.component';
import { UserDetailComponent } from './components/children/user-detail/user-detail.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  {
    path: '',
    component: MainComponent,
    children: [
      { path: '', component: DataTableComponent },
      { path: 'create', component: CreateTaskComponent },
      { path: 'TicketDetails', component: TicketDetailComponent },
      { path: 'UserDetails', component: UserDetailComponent },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
