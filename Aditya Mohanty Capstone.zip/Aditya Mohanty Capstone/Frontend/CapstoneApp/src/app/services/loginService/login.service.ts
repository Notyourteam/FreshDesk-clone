import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { forkJoin, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Constant } from '../../Utilities/Urls/constant';
import { User } from 'src/app/Utilities/Users/User';
import { UserPost } from 'src/app/Utilities/Users/UserPost';
@Injectable({
  providedIn: 'root'
})
export class LoginService {
  constructor(private http: HttpClient) { }

  getUser(email: string): Observable<User[]> {
    return this.http
      .get(`${Constant.loginEndPoint.toString()}${email}`)
      .pipe<User[]>(map((data: any) => data));
  }
  getAllUser(): Observable<User[]> {
    return this.http
      .get(`${Constant.loginEndPoint.toString()}`)
      .pipe<User[]>(map((data: any) => data));
  }


  addUser(data: UserPost): Observable<User> {
    return this.http.post<User>(`${Constant.loginEndPoint.toString()}`, data);
  }

  deleteUser(id: number): Observable<User> {
    return this.http.delete<User>(`${Constant.loginEndPoint.toString()}/${id}`);
  }

  deleteUsers(datas: any): Observable<any> {
    return forkJoin(
      datas.map((data: any) =>
        this.http.delete<User>(`${Constant.loginEndPoint.toString()}/${data.id}`)
      ));
  }
}
