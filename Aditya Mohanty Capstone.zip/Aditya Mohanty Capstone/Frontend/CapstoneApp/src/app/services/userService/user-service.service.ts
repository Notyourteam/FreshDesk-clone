import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { forkJoin, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { TicketData } from '../../Utilities/Tickets/TicketData';
import { Ticket } from '../../Utilities/Tickets/Ticket';
import { Constant } from '../../Utilities/Urls/constant';
import { TicketPost } from 'src/app/Utilities/Tickets/TicketPost';
@Injectable({
  providedIn: 'root',
})
export class UserService {
  //private serviceUrl = 'https://635d77c9ea764497f0dd5e33.mockapi.io/ticket';
  constructor(private http: HttpClient) { }

  getTickets(): Observable<TicketData[]> {
    return this.http
      .get(Constant.getEndpoint.toString())
      .pipe<Ticket[]>(map((data: any) => data));
  }

  updateTicket(data: TicketData): Observable<TicketData> {
    console.log(data.id);
    return this.http.put<Ticket>(`${Constant.getEndpoint.toString()}/${data.id}`, data);
  }

  addTicket(data: TicketPost): Observable<TicketData> {
    return this.http.post<Ticket>(`${Constant.getEndpoint.toString()}`, data);
  }

  deleteTicket(id: number): Observable<TicketData> {
    return this.http.delete<Ticket>(`${Constant.getEndpoint.toString()}/${id}`);
  }

  deleteTickets(datas: any): Observable<any> {
    return forkJoin(
      datas.map((data: any) =>
        this.http.delete<Ticket>(`${Constant.getEndpoint.toString()}/${data.id}`)
      ));
  }
}
