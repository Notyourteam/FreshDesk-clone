﻿using System;
using System.Collections.Generic;

namespace CapAPI.Models
{
    public partial class UserLogin
    {
        public UserLogin()
        {
            Tickets = new HashSet<Ticket>();
        }

        public string EmailId { get; set; } = null!;
        public string Password { get; set; } = null!;
        public string Name { get; set; } = null!;
        public int Admin { get; set; }

        public virtual ICollection<Ticket> Tickets { get; set; }
    }
}
