﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace CapAPI.Models
{
    public partial class newCapstoneContext : DbContext
    {
        public newCapstoneContext()
        {
        }

        public newCapstoneContext(DbContextOptions<newCapstoneContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Ticket> Tickets { get; set; } = null!;
        public virtual DbSet<UserLogin> UserLogins { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=APINP-ELPT54193\\SQLEXPRESS;Database=newCapstone;Integrated Security=false;User Id=sa;Password=guvi;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Ticket>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK__Tickets__3214EC0711F7514C");

                entity.ToTable("Tickets");

                entity.Property(e => e.Id).HasColumnName("Id");

                entity.Property(e => e.AgentEmail)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("agent_email");

                entity.Property(e => e.AgentName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("agent_name");

                entity.Property(e => e.AuthorEmail)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("author_email");

                entity.Property(e => e.CreatedAt)
                    .HasColumnType("date")
                    .HasColumnName("createdAt");

                entity.Property(e => e.Description)
                    .IsUnicode(false)
                    .HasColumnName("description");

                entity.Property(e => e.DueBy)
                    .HasColumnType("date")
                    .HasColumnName("due_by");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("name");

                entity.Property(e => e.Priority)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("priority");

                entity.Property(e => e.Status)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("status");

                entity.Property(e => e.Subject)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("subject");

                entity.Property(e => e.Type)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("type");

                entity.HasOne(d => d.AuthorEmailNavigation)
                .WithMany(x =>x.Tickets)
                    .HasForeignKey(d => d.AuthorEmail)
                    .HasConstraintName("FK_Tickets_ToTable");
            });

            modelBuilder.Entity<UserLogin>(entity =>
            {
                entity.HasKey(e => e.EmailId)
                    .HasName("PK__UserLogi__3FEF87669AC0DB15");

                entity.ToTable("UserLogin");

                entity.Property(e => e.EmailId)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("email_id");

                entity.Property(e => e.Admin).HasColumnName("admin");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("name");

                entity.Property(e => e.Password)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("password");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
